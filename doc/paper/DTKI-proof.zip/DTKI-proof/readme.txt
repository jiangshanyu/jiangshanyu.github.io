Usage:
- Use a Tamarin version with support for 'L_' prefixed facts. I used
  git commit f1a215550d95d57d3e59267a4fb268dfbf6e826e, but the current
  'feature-external-heuristic' branch should work just fine.
- On my machine [1] the command-line usage:

    time tamarin-prover --prove DTKI-proof.spthy >proof_result.txt

  takes about 10 minutes of user time, where proof_result.txt records
  the running result and the running time.

