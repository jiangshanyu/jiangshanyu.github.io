Updates:

- 01 June 2015: Updated readme.txt with better installation instructions,
  since the development branch now compiles on more platforms and has
  lower requirements.

-------------------------------------
Requirements:
-------------------------------------

The following instructions have been successful for Linux users:

- First install m4, maude, graphviz, zlib1g-dev, ghc, cabal-install
  (alex and happy are no longer needed)

- Compile the development branch of the Tamarin prover:

  https://github.com/tamarin-prover/tamarin-prover/archive/develop.zip

  And then run 'make' in the unzipped Tamarin directory.


  (Note that somewhat outdated installation instructions are here:
  http://www.infsec.ethz.ch/research/software/tamarin.html )


For Windows users, it is currently recommended to use a virtual machine based
on Vagrant (https://www.vagrantup.com/). Please use the following
Vagrantfile:

  https://github.com/tamarin-prover/tamarin-prover/raw/28ef4a307bd2c4aca56440f65ca58e1556a3362a/misc/Vagrantfile



-------------------------------------
Usage:
-------------------------------------

- In this directory, run 'make' to generate spthy files using 'm4'. This produces:
  * DECIM-correctness.spthy
  * DECIM-secrecy.spthy
  * (etc)
   
  The 'm4' files encode the individual properties. These files all
  depend on 'DECIM-base.inc', which specifies the DECIM protocol model as
  rewrite rules. 

- Use a Tamarin version with support for 'L_' prefixed facts. I used
  git commit f1a215550d95d57d3e59267a4fb268dfbf6e826e, the latest
  version work just fine with --heuristic=S option.


- Then use the command line. E.g., for us,

    $ tamarin-prover --prove DECIM.correctness.spthy

  takes about 4 seconds of user time, and

    $ tamarin-prover --prove DECIM.secrecy.spthy

  takes about 20 seconds of user time.

  To see the generated traces, use Tamarin's interactive mode:

    $ tamarin-prover interactive .

  Note that if the above command fails with an "openfile" error, it
  probably indicates that the tool was compiled without GUI support -
  this is something to resolve during the 'make' of the tool.


